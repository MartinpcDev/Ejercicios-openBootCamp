public class Main {
    public static void main(String[] args) {
        String[] textos = {"hola", "mundo" , "estoy" , "programando"};
        String resultadosinespacios = "";
        String resultadoconespacios = "";
        for (int i = 0 ; i < textos.length ; i++){
            resultadoconespacios += textos[i] + " ";
        }
        for (int i = 0 ; i < textos.length ; i++){
            resultadosinespacios += textos[i];
        }
        System.out.println(resultadoconespacios);
        System.out.println(resultadosinespacios);

    }
}