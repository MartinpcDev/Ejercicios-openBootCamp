public class SmartDevice {
    String brand;
    String model;
    double screenSize;
    int batteryCapacity;

    public SmartDevice() {
    }

    public SmartDevice(String brand, String model, double screenSize, int batteryCapacity) {
        this.brand = brand;
        this.model = model;
        this.screenSize = screenSize;
        this.batteryCapacity = batteryCapacity;
    }
}
