public class Main {
    public static void main(String[] args) {
        double price = 1385;
        System.out.println("El precio con la IVA incluida de " +price + " es: "+getPriceIVA(price));

    }

    static double getPriceIVA(double price){
        double IVA = price * 18/100;
        double resultado = price + IVA;

        return resultado;
    }
}