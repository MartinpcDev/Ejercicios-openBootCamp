public class Coche {

    String marca;
    String modelo;
    String placa;
    int caballosFuerza;
}
